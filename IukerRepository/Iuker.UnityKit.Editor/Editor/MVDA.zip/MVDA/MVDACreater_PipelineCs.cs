﻿
using Iuker.UnityKit.Run.Module.View.MVDA;
using UnityEditor;

namespace Iuker.UnityKit.Editor.MVDA
{
    /// <summary>
    /// MVDA视图脚本创建器视图生命周期脚本创建
    /// </summary>
    public partial class MVDACreater
    {
        public static void CreateViewPipelinedScripts()
        {
            if (sIsError) return;

            CreateActionResponserScript(seletedGo.name, "BeforeCreate", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "OnCreated", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "BeforeHide", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "OnHided", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "BeforeActive", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "OnActived", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "BeforeClose", "Pipeline", "IView", ViewScriptType.Pipeline);
            CreateActionResponserScript(seletedGo.name, "OnClosed", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnCreateScripts()
        {
            if (sIsError) return;

            CreateActionResponserScript(seletedGo.name, "BeforeCreate", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnCreatedScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "OnCreated", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnHideScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "BeforeHide", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnHidedScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "OnHided", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnActiveScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "BeforeActive", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnActivedScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "OnActived", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnCloseScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "BeforeClose", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }

        public static void CreateViewPipelinedOnClosedScripts()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "OnClosed", "Pipeline", "IView", ViewScriptType.Pipeline);
            AssetDatabase.Refresh();
        }






    }
}