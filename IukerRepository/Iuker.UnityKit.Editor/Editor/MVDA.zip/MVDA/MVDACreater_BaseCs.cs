﻿using System.IO;
using System.Text;
using Iuker.Common;
using Iuker.UnityKit.Run.LinqExtensions;
using Iuker.UnityKit.Run.Base.Config.Develop;
using Iuker.UnityKit.Run.Module.View.ViewWidget;
using UnityEditor;
using UnityEngine;

namespace Iuker.UnityKit.Editor.MVDA
{
    /// <summary>
    /// MVDA视图脚本创建器=>视图容器脚本创建
    /// </summary>
    public partial class MVDACreater : MVDACreaterBase
    {
        public void CsContainerAndConstant()
        {
            if (sIsError) return;
            CreateViewScript(); // 视图容器脚本
            CreateViewConstantScript(); // 视图常量脚本
            AssetDatabase.Refresh();
        }

        private static void CreateViewConstantScript()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendCsahrpFileInfo(EditorConstant.HostClientName, EditorConstant.HostClientEmail);
            sb.AppendLine($"namespace {RootConfig.GetCurrentProject().ProjectName}");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {seletedGo.name}_Constant");
            sb.AppendLine("    {");
            _viewWidgetGetPathList.ForEach(r => sb.AppendLine($"        public const string {r.Name} = {r.Path};"));
            sb.AppendLine("    }");
            sb.AppendLine("}");
            // 生成脚本文件
            var targetDir = RootConfig.GetCurrentSonProject().CsMvdaDir + seletedGo.name + "/";
            if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);
            var targetScriptPath = targetDir + seletedGo.name + "_Constant.cs";
            File.WriteAllText(targetScriptPath, sb.ToString());
            AssetDatabase.Refresh();
            _viewWidgetGetPathList.Clear();
        }

        private static void CreateViewScript()
        {
            Debug.Log($"视图{seletedGo.name}下符合命名规则的视图控件数量为：" + viewWidgetsDictionary.Count);
            var sb = new StringBuilder();

            sb.AppendCsahrpFileInfo(EditorConstant.HostClientName, EditorConstant.HostClientEmail);
            WriteViewScriptNameSpace(sb);
            sb.AppendLine($"namespace {RootConfig.GetCurrentProject().ProjectName}");
            sb.AppendLine("{");
            sb.AppendLine($"public class {seletedGo.name} : AbsViewBase");
            sb.AppendLine("{");
            WriteViewActionConstant(sb);

            sb.AppendLine("    #region 视图控件字段");
            sb.AppendLine("    #endregion");
            sb.AppendLine();

            // 获取控件脚本代码生成
            CreateGetViewWidgets(sb);

            sb.AppendLine("    #region 视图生命周期");
            WriteViewOverride(sb);
            sb.AppendLine("    #endregion");

            sb.AppendLine("}");
            sb.AppendLine("}");

            // 生成脚本文件
            var targetDir = RootConfig.GetCurrentSonProject().CsMvdaDir + seletedGo.name + "/";
            if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);
            var targetScriptPath = targetDir + seletedGo.name + ".cs";
            File.WriteAllText(targetScriptPath, sb.ToString());
            AssetDatabase.Refresh();
        }


        private static void WriteViewActionConstant(StringBuilder sb)
        {
            var viewHoldStr = "\"" + seletedGo.name;
            sb.AppendLine("    // 视图行为字符串常量，避免临时字符串反复构建消耗。");
            sb.AppendLine($"    private const string _onBeforeCreatActionToken = {viewHoldStr}_BeforeCreat" + "\";");
            sb.AppendLine($"    private const string _onCreatedActionToken = {viewHoldStr}_OnCreated" + "\";");
            sb.AppendLine($"    private const string _onBeforeActiveActionToken = {viewHoldStr}_BeforeActive" + "\";");
            sb.AppendLine($"    private const string _onActivedActionToken = {viewHoldStr}_OnActived" + "\";");
            sb.AppendLine($"    private const string _onBeforeHideActionToken = {viewHoldStr}_BeforeHide" + "\";");
            sb.AppendLine($"    private const string _onHidedActionToken = {viewHoldStr}_OnHided" + "\";");
            sb.AppendLine($"    private const string _onBeforeCloseActionToken = {viewHoldStr}_BeforeClose" + "\";");
            sb.AppendLine($"    private const string _onClosedActionToken = {viewHoldStr}_OnClosed" + "\";");
            sb.AppendLine($"    private const string _onCreatedDrawActionToken = {viewHoldStr}_Draw_OnCreated" + "\";");
            sb.AppendLine($"    private const string _onActivedDrawActionToken = {viewHoldStr}_Draw_OnActived" + "\";");
            sb.AppendLine($"    private const string _onHideDrawActionToken = {viewHoldStr}_Draw_OnHide" + "\";");
            sb.AppendLine($"    private const string _onCloseDrawActionToken = {viewHoldStr}_Draw_OnClose" + "\";");
            sb.AppendLine();
        }


        private static void CreateGetViewWidgets(StringBuilder sb)
        {
            sb.AppendLine("    protected override void InitViewWidgets()");
            sb.AppendLine("    {");
            sb.AppendLine("        base.InitViewWidgets();");
            sb.AppendLine();

            // 容器对象
            sb.AppendLine("        // 容器对象");
            _containerList.ForEach(r =>
            {
                var target = viewWidgetsDictionary[r];
                var getPath = GetWidgetPath(target, target.Parent(), "");
                _viewWidgetGetPathList.Add(new WidgetPathInfo(target.name, getPath));
                sb.AppendLine(string.Format("        RectRoot.Find({0}).gameObject.AddTo({0},ContainerDictionary);", getPath));
            });
            sb.AppendLine();

            WriteViewWidgetCode(sb, "按钮对象", typeof(IButton).Name, _buttonList, "ButtonDictionary");     // 按钮对象
            WriteViewWidgetCode(sb, "文本对象", typeof(IText).Name, _textList, "TextDictionary");     // 文本对象
            WriteViewWidgetCode(sb, "输入框对象", typeof(IInputField).Name, _inputFieldList, "InputFieldDictionary");     // 输入框对象
            WriteViewWidgetCode(sb, "Image对象", typeof(IImage).Name, _imageList, "ImageDictionary"); //  图片对象
            WriteViewWidgetCode(sb, "RawImage对象", typeof(IRawImage).Name, _rawImageList, "RawImageDictionary"); //  原始图片对象
            WriteViewWidgetCode(sb, "Toggle对象", typeof(IToggle).Name, _toggleList, "ToggleDictionary"); //  开关对象
            WriteViewWidgetCode(sb, "Slider对象", typeof(ISlider).Name, _sliderList, "SliderDictionary"); //  滑动杆对象
            WriteViewWidgetCode(sb, "TabGroup对象", typeof(ITabGroup).Name, _tabgroupList, "TabGroupDictionary"); //  滑动杆对象
            WriteViewWidgetCode(sb, "ListView对象", typeof(IListView).Name, _listViewList, "ListViewDictionary"); //  滚动列表对象

            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine();
        }


        private static void WriteViewOverride(StringBuilder sb)
        {
            WriteStandardMethod(sb, "    protected override void BeforeCreat()", @"
        base.BeforeCreat();
        var onCreateRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onBeforeCreatActionToken,ViewScriptType.Pipeline);
        Issue(onCreateRequest);
");

            WriteStandardMethod(sb, "    protected override void OnCreated()", @"
        base.OnCreated();
        var onCreatedRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onCreatedActionToken,ViewScriptType.Pipeline);
        Issue(onCreatedRequest);
        var onCreatedDrawRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>()
            .Init(this, _onCreatedDrawActionToken,ViewScriptType.Draw);
        Issue(onCreatedDrawRequest);   
");

            WriteStandardMethod(sb, "    protected override void BeforeActive()", @"
        base.BeforeActive();
        var onActiveRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onBeforeActiveActionToken,ViewScriptType.Pipeline);
        Issue(onActiveRequest);
");

            WriteStandardMethod(sb, "    protected override void OnActived()", @"
        base.OnActived();
        var onActivedRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onActivedActionToken,ViewScriptType.Pipeline);
        Issue(onActivedRequest);
        var onActivedDrawRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>()
            .Init(this, _onActivedDrawActionToken,ViewScriptType.Draw);
        Issue(onActivedDrawRequest);   
");

            WriteStandardMethod(sb, "    protected override void BeforeHide()", @"
        base.BeforeHide();
        var onHideRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onBeforeHideActionToken,ViewScriptType.Pipeline);
        Issue(onHideRequest);
        var onHideDrawRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>()
            .Init(this, _onHideDrawActionToken,ViewScriptType.Draw);
        Issue(onHideDrawRequest);   
");

            WriteStandardMethod(sb, "    protected override void OnHided()", @"
        base.OnHided();
        var onHidedRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onHidedActionToken,ViewScriptType.Pipeline);
        Issue(onHidedRequest);
");

            WriteStandardMethod(sb, "    protected override void BeforeClose()", @"
        base.BeforeClose();
        var onCloseRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onBeforeCloseActionToken,ViewScriptType.Pipeline);
        Issue(onCloseRequest);
        var onCloseDrawRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>()
            .Init(this, _onCloseDrawActionToken,ViewScriptType.Draw);
        Issue(onCloseDrawRequest);   
");

            WriteStandardMethod(sb, "    protected override void OnClosed()", @"
        base.OnClosed();
        var onClosedRequest = U3DFrame.InjectModule.GetInstance<IViewActionRequest<IView>>().Init(this, _onClosedActionToken,ViewScriptType.Pipeline);
        Issue(onClosedRequest);
");
        }





    }
}
