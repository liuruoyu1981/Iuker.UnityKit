﻿
using System.IO;
using System.Text;
using Iuker.Common;
using Iuker.UnityKit.Run.Base.Config.Develop;
using UnityEditor;

namespace Iuker.UnityKit.Editor.MVDA
{
    public partial class MVDACreater
    {
        public static void MenuViewModel()
        {
            if (sIsError) return;
            CreateViewModelScript();    // 视图数据模型脚本
            AssetDatabase.Refresh();
        }

        private static void CreateViewModelScript()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendCsahrpFileInfo(EditorConstant.HostClientName, EditorConstant.HostClientEmail);
            WriteViewModelNameSpace(sb);
            sb.AppendLine($"namespace {RootConfig.GetCurrentProject().ProjectName}");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {seletedGo.name + "_Model"} : IViewModel");
            sb.AppendLine("    {");
            sb.AppendLine("        private IU3dFrame _u3DFrame;");
            sb.AppendLine();
            sb.AppendLine("        public IViewModel Init(IU3dFrame U3DFrame)");
            sb.AppendLine("        {");
            sb.AppendLine("            _u3DFrame = U3DFrame;");
            sb.AppendLine("            return this;");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            var targetDir = RootConfig.GetCurrentSonProject().CsMvdaDir + seletedGo.name + "/";
            if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);
            var targetScriptPath = targetDir + seletedGo.name + "_Model.cs";
            File.WriteAllText(targetScriptPath, sb.ToString());
            AssetDatabase.Refresh();
        }




    }
}