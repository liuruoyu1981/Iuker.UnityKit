﻿
using Iuker.UnityKit.Run.Module.View.MVDA;
using UnityEditor;

namespace Iuker.UnityKit.Editor.MVDA
{
    /// <summary>
    /// MVDA视图脚本创建器视图效果脚本创建
    /// </summary>
    public partial class MVDACreater
    {
        public static void MenuViewDrawAll()
        {
            if (sIsError) return;
            CreateViewDrawerScripts(); // 视图效果脚本
            AssetDatabase.Refresh();
        }

        public static void MenuViewDrawOnCreated()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "OnCreated", "Draw", "IView", ViewScriptType.Draw);
            AssetDatabase.Refresh();
        }

        public static void MenuViewDrawBeforeHide()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "BeforeHide", "Draw", "IView", ViewScriptType.Draw);
            AssetDatabase.Refresh();
        }

        public static void MenuViewDrawOnActived()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "OnActived", "Draw", "IView", ViewScriptType.Draw);
            AssetDatabase.Refresh();
        }

        public static void MenuViewDrawBeforeClose()
        {
            if (sIsError) return;
            CreateActionResponserScript(seletedGo.name, "BeforeClose", "Draw", "IView", ViewScriptType.Draw);
            AssetDatabase.Refresh();
        }
    }
}