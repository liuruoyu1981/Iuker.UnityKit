﻿/***********************************************************************************************
Author：liuruoyu1981
CreateDate: 2017/03/07 10:50:54
Email: 35490136@qq.com
QQCode: 35490136
CreateNote: 
***********************************************************************************************/


/****************************************修改日志***********************************************
1. 修改日期： 修改人： 修改内容：
2. 修改日期： 修改人： 修改内容：
3. 修改日期： 修改人： 修改内容：
4. 修改日期： 修改人： 修改内容：
5. 修改日期： 修改人： 修改内容：
****************************************修改日志***********************************************/


using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Iuker.Common;
using Iuker.UnityKit.Run.LinqExtensions;
using Iuker.UnityKit.Run.Base.Config.Develop;
using Iuker.UnityKit.Run.Module.View.MVDA;
using UnityEditor;

namespace Iuker.UnityKit.Editor.MVDA
{
    /// <summary>
    /// 脚本创建插件
    /// </summary>
    public partial class MVDACreater : MVDACreaterBase
    {
        #region ViewScript

        private static void WriteViewScriptNameSpace(StringBuilder sb)
        {
            sb.AppendLine("using Iuker.UnityKit.Run.Module.View.MVDA;");
            sb.AppendLine("using Iuker.UnityKit.Run.ViewWidget;");
            sb.AppendLine("using UnityEngine;");
            sb.AppendLine("using Iuker.UnityKit.Run.Module.View.ViewWidget;");
            sb.AppendLine();
        }

        private static readonly List<WidgetPathInfo> _viewWidgetGetPathList = new List<WidgetPathInfo>();

        /// <summary>
        /// 写入视图控件获取代码
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="node"></param>
        /// <param name="interfaceType"></param>
        /// <param name="elementList"></param>
        /// <param name="dictionaryName"></param>
        private static void WriteViewWidgetCode(StringBuilder sb, string node, string interfaceType, List<string> elementList, string dictionaryName)
        {
            sb.AppendLine($"        // {node}");
            elementList.ForEach(r =>
            {
                var targetObj = viewWidgetsDictionary[r];
                var getPath = GetWidgetPath(targetObj, targetObj.Parent(), "");
                _viewWidgetGetPathList.Add(new WidgetPathInfo(targetObj.name, getPath));
                sb.AppendLine(string.Format("        InitViewWidget<{1}>({2}).AddTo({2},{3});", r, interfaceType, getPath, dictionaryName));
            });
            sb.AppendLine();
        }



        private static void WriteViewModelNameSpace(StringBuilder sb)
        {
            sb.AppendLine("using Iuker.UnityKit.Run.Base;");
            sb.AppendLine("using Iuker.UnityKit.Run.Module.View.MVDA;");
            sb.AppendLine();
        }

        #endregion

        /// <summary>
        /// 创建视图行为处理器脚本
        /// </summary>
        /// <param name="elementName">UI控件名</param>
        /// <param name="actionName">视图行为名</param>
        /// <param name="dirName">视图脚本目录</param>
        /// <param name="genericType"></param>
        /// <param name="type"></param>
        /// <param name="isCell">是否为模板控件</param>
        private static void CreateActionResponserScript(string elementName, string actionName, string dirName, string genericType, ViewScriptType type = ViewScriptType.Widget, bool isCell = false)
        {
            StringBuilder sb = new StringBuilder();
            var time = DateTime.Now.ToString("MMddHHmmss");
            string classname;
            if (isCell)
            {
                classname = seletedGo.name + "_" + elementName + "_" + actionName;
            }
            else
            {
                classname = GetClassName(type, elementName, actionName, time);
            }
            sb.AppendCsahrpFileInfo(EditorConstant.HostClientName, EditorConstant.HostClientEmail,
                "视图行为处理器脚本，在这里实现视图控件交互、视图生命周期的行为处理逻辑。");
            //WriteFileInfo(sb, "视图行为处理器脚本，在这里实现视图控件交互、视图生命周期的行为处理逻辑。");
            WriteViewActionNameSpace(sb);
            sb.AppendLine($"namespace {RootConfig.GetCurrentProject().ProjectName}");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {classname} : IViewActionResponser<{genericType}>");
            sb.AppendLine("    {");
            sb.AppendLine("        private IU3dFrame mU3DFrame;");
            sb.AppendLine($"        private  IViewActionRequest<{genericType}> _viewActionRequest;");
            sb.AppendLine("        private  IView mView;");
            sb.AppendLine();

            sb.AppendLine(string.Format("        public IViewActionResponser<{0}> Init(IU3dFrame frame,IViewActionRequest<{0}> request,IViewModel model)"
                , genericType));
            sb.AppendLine("        {");
            sb.AppendLine("            mU3DFrame = frame;");
            sb.AppendLine("            mView = request.ActionRequester.Origin.AttachView;");
            sb.AppendLine("            return this;");
            sb.AppendLine("        }");
            sb.AppendLine();

            // 关注视图Id与关注视图开启状态
            Extensions.AppendCsharpNote(sb, "行为处理器关注的视图Id", null, null, "        ");
            sb.AppendLine("        public string ConcernedViewId =>" + "\"" + seletedGo.name + "\"" + ";");
            sb.AppendLine();
            Extensions.AppendCsharpNote(sb, "行为处理器关注的视图的开启状态", null, null, "        ");
            sb.AppendLine("        public bool IsConcernedViewClosed { get; set; }");
            sb.AppendLine();

            sb.AppendLine($"        public void ProcessRequest(IViewActionRequest<{genericType}> request)");
            sb.AppendLine("        {");
            sb.AppendLine("            _viewActionRequest = request;");
            sb.AppendLine("#if UNITY_EDITOR || DEBUG");
            sb.AppendLine(string.Format("            Debuger.Log({0}{1}_{2} is  {3}{0});", "\"", seletedGo.name, elementName, actionName));
            sb.AppendLine("#endif");
            sb.AppendLine("        }");
            sb.AppendLine();

            WriteStandardMethod(sb, "        public bool CheckProcessResult()", "        return true;", "    ");
            WriteStandardMethod(sb, "        public void ProcessException(Exception ex)", null, "    ");
            sb.AppendLine(string.Format("        public {0} Origin {1}", genericType, " { get { return _viewActionRequest.ActionRequester.Origin; } }"));
            sb.AppendLine();

            sb.AppendLine("    }");
            sb.AppendLine("}");
            // 生成脚本文件
            string targetDir = null;
            if (!isCell)
            {
                targetDir = RootConfig.GetCurrentSonProject().CsMvdaDir + seletedGo.name + "/" + dirName + "/" + actionName + "/";
            }
            else
            {
                targetDir = RootConfig.GetCurrentSonProject().CsMvdaDir + dirName + "/Cell/";
            }

            if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);
            var targetScriptPath = targetDir + classname + ".cs";
            File.WriteAllText(targetScriptPath, sb.ToString());
        }

        private static string GetClassName(ViewScriptType type, string elementName, string actionName, string time)
        {
            string classname = null;
            switch (type)
            {
                case ViewScriptType.Pipeline:
                    classname = elementName + "_" + actionName + "_" + time;
                    break;
                case ViewScriptType.Widget:
                    classname = seletedGo.name + "_" + elementName + "_" + actionName + time;
                    break;
                case ViewScriptType.Draw:
                    classname = seletedGo.name + "_Draw" + "_" + actionName;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type), type, null);
            }
            return classname;
        }


        private static void CreateInputFieldScripts()
        {
            _inputFieldList.ForEach(name => CreateActionResponserScript(name, "OnSelect", "InputField" + "/" + name, "IInputField"));
            _inputFieldList.ForEach(name => CreateActionResponserScript(name, "OnValueChanged", "InputField" + "/" + name, "IInputField"));
            _inputFieldList.Clear();
            viewWidgetsDictionary.Clear();
        }

        private static void CreateToggleScripts()
        {
            _toggleList.ForEach(name => CreateActionResponserScript(name, "OnValueChanged", "Toggles" + "/" + name, "IToggle"));
            _toggleList.Clear();
            viewWidgetsDictionary.Clear();
        }

        private static void CreateSliderScripts()
        {
            _sliderList.ForEach(name => CreateActionResponserScript(name, "OnValueChanged", "Slider" + "/" + name, "ISlider"));
            _sliderList.Clear();
            viewWidgetsDictionary.Clear();
        }

        private static void WriteViewActionNameSpace(StringBuilder sb)
        {
            sb.AppendLine("using System;");
            sb.AppendLine("using Iuker.Common;");
            sb.AppendLine("using Iuker.UnityKit.Run.Module.View.MVDA;");
            sb.AppendLine("using Iuker.UnityKit.Run.Module.View.ViewWidget;");
            sb.AppendLine("using Iuker.UnityKit.Run.Base;");
            sb.AppendLine();
        }

        private static void CreateViewDrawerScripts()
        {
            CreateActionResponserScript(seletedGo.name, "OnCreated", "Draw", "IView", ViewScriptType.Draw);
            CreateActionResponserScript(seletedGo.name, "BeforeHide", "Draw", "IView", ViewScriptType.Draw);
            CreateActionResponserScript(seletedGo.name, "OnActived", "Draw", "IView", ViewScriptType.Draw);
            CreateActionResponserScript(seletedGo.name, "BeforeClose", "Draw", "IView", ViewScriptType.Draw);
            AssetDatabase.Refresh();
        }

        #region 通讯器脚本创建

        //[MenuItem("GameObject/Iuker/MVDA/C#/Opsater")]
        //private static void MenuOpsatScript()
        //{
        //    if (Selection.gameObjects.Length == 1 && Selection.gameObjects[0].name.StartsWith("button"))
        //    {
        //        _selectedGameObject = Selection.gameObjects[0];
        //        CreateOpsaterScript();
        //    }
        //    else
        //    {
        //        EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件并且目标只能是按钮，请重新选择！", "确定");
        //        return;
        //    }
        //    _selectedGameObject = null;
        //    AssetDatabase.Refresh();
        //}

        ///// <summary>
        ///// 创建一个用于发起通讯的通讯器脚本
        ///// </summary>
        //private static void CreateOpsaterScript()
        //{
        //    StringBuilder sb = new StringBuilder();
        //    WriteFileInfo(sb);
        //    WriteOpsaterNameSpace(sb);
        //    WriteOpsaterBody(sb);
        //    // 生成脚本文件
        //    var targetDir = RootConfig.CsOpsatDir + "/" + opsatClass() + "/";
        //    if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);
        //    var targetPath = targetDir + OpsaterClassName() + ".cs";
        //    File.WriteAllText(targetPath, sb.ToString());
        //    AssetDatabase.Refresh();
        //    InternalEditorUtility.OpenFileAtLineExternal(targetPath, 1);
        //}

        //private static void WriteOpsaterNameSpace(StringBuilder sb)
        //{
        //    sb.AppendLine("using System;");
        //    sb.AppendLine("using Iuker.UnityKit.Run.Base;");
        //    sb.AppendLine("using Iuker.UnityKit.Run.Module.Net;");
        //    sb.AppendLine("using Iuker.UnityKit.Run.Module.View.ViewWidget;");
        //    sb.AppendLine();
        //}

        //private static GameObject _opsatGameObject;

        //private static string opsatClass()
        //{
        //    ViewWidgetsExtensions.FindViewRoot(_selectedGameObject.Parent(), out _opsatGameObject);
        //    var result = _opsatGameObject.name + "_" + _selectedGameObject.name;
        //    return result;
        //}

        //private static string OpsaterClassName()
        //{
        //    ViewWidgetsExtensions.FindViewRoot(_selectedGameObject.Parent(), out _opsatGameObject);
        //    var result = _opsatGameObject.name + "_" + _selectedGameObject.name + "_opsat_" + Constant.GetTimeToken;
        //    return result;
        //}

        //private static void WriteOpsaterBody(StringBuilder sb)
        //{
        //    sb.AppendLine("namespace " + RootConfig.GetCurrentProject().ProjectName);
        //    sb.AppendLine("{");
        //    sb.AppendLine($"    public class {OpsaterClassName()} : IOpsatResponser<{GetOpsatGenericType()}>");
        //    sb.AppendLine("    {");
        //    sb.AppendLine("        private IU3dFrame _u3DFrame;");
        //    sb.AppendLine();
        //    UnityExtensions.WriteNote(sb, "在这里执行通信请求处理器的初始化", null, null, "        ");
        //    WriteStandardMethod(sb, "        public void Init(IU3dFrame U3DFrame)", "        _u3DFrame = U3DFrame;", "        ");
        //    UnityExtensions.WriteNote(sb, "在这里处理通信请求", null, null, "        ");
        //    WriteStandardMethod(sb, $"        public void ProcessRequest(IOpsatRequest<{GetOpsatGenericType()}> request)", "    ", "        ");
        //    UnityExtensions.WriteNote(sb, "在这里进行模拟通信", null, null, "        ");
        //    WriteStandardMethod(sb, "        public void Simulate()", "    ", "        ");
        //    UnityExtensions.WriteNote(sb, "在这里检查通信结果", null, null, "        ");
        //    WriteStandardMethod(sb, "        public bool CheckProcessResult()", "        return true;", "        ");
        //    UnityExtensions.WriteNote(sb, "在这里进行自定义异常处理", null, null, "        ");
        //    WriteStandardMethod(sb, "        public void ProcessException(Exception ex)", "    ", "        ");
        //    sb.AppendLine("    }");
        //    sb.AppendLine("}");
        //}

        //private static string GetOpsatGenericType()
        //{
        //    if (_selectedGameObject.name.Contains("button")) return "IButton";


        //    return null;
        //}

        #endregion

        private static void WriteStandardMethod(StringBuilder sb, string methadHead, string methodBody = "    ", string space = null)
        {
            sb.AppendLine(methadHead);
            sb.AppendLine(space + "{");
            sb.AppendLine(space + methodBody);
            sb.AppendLine(space + "}");
            sb.AppendLine();
        }


        #region Lua视图脚本创建


        private static void WriteDefaultTable(StringBuilder sb) => sb.AppendLine($"local {seletedGo.name} = {{}}");

        private static void WriteLuaInitViewWidgets(StringBuilder sb)
        {
            sb.AppendLine($"{seletedGo.name}.InitViewWidgets = function()");
            WriteLuaViewWidgetCode(sb, "Container", _containerList);
            WriteLuaViewWidgetCode(sb, "Button", _buttonList);
            WriteLuaViewWidgetCode(sb, "Text", _textList);
            WriteLuaViewWidgetCode(sb, "InputField", _inputFieldList);
            sb.AppendLine("end");
        }

        private static void WriteLuaViewWidgetCode(StringBuilder sb, string widgetType, List<string> elementList)
        {
            sb.AppendLine($"        -- {widgetType}");
            elementList.ForEach(r =>
            {
                var targetObj = viewWidgetsDictionary[r];
                var getPath = GetWidgetPath(targetObj, targetObj.Parent(), "");
                _viewWidgetGetPathList.Add(new WidgetPathInfo(targetObj.name, getPath));
                sb.AppendLine($"        {seletedGo.name}.view.InitLuaViewWidget('{widgetType}',{getPath});");
            });
            sb.AppendLine();
        }

        private static void WriteLuaViewConstantFiled(StringBuilder sb, string widgetType, List<string> elementList)
        {
            sb.AppendLine($"-- {widgetType}");
            elementList.ForEach(r =>
            {
                var targetObj = viewWidgetsDictionary[r];
                var getPath = GetWidgetPath(targetObj, targetObj.Parent(), "");
                _viewWidgetGetPathList.Add(new WidgetPathInfo(targetObj.name, getPath));
                sb.AppendLine($"{seletedGo.name + "_Constant"}.{targetObj.name} = {getPath}");
            });
            sb.AppendLine();
        }

        #endregion


    }
}
