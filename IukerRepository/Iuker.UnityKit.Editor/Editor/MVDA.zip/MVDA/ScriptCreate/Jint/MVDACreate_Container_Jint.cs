﻿using System.Collections.Generic;
using System.Text;
using Iuker.Common;
using Iuker.Common.Utility;
using Iuker.UnityKit.Run.Base;
using Iuker.UnityKit.Run.Base.Config;
using Iuker.UnityKit.Run.LinqExtensions;
using UnityEditor;
using UnityEngine;

namespace Iuker.UnityKit.Editor.MVDA.ScriptCreate.Jint
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class MVDACreate_Container_Jint : MVDAJintCreateBase
    {
        public void MenuViewBaseJintContainerAndConstant()
        {
            var targetDir = mSelectSon.TsProjectMvdaDir;
            var containerPath = targetDir + seletedGo.name + "_jint.ts";
            var constantPath = targetDir + seletedGo.name + "_constant_jint.ts";

            CreateJintContainer(mSelectSon, containerPath);
            CreateJintConstant(mSelectSon, constantPath);
            Debug.Log($"视图{_viewRoot.name}的Ts容器及常量脚本已成功创建！");
            AssetDatabase.Refresh();
        }

        private void CreateJintContainer(SonProject son, string targetScriptPath)
        {
            var sb = new StringBuilder().AppendTypeScriptFileNode(EditorConstant.HostClientName,
                EditorConstant.HostClientEmail, "视图容器Typescript脚本（使用Jint执行引擎）。");
            WriteNameSpaceHeader(sb);
            sb.AppendLine();
            sb.AppendLine($"    export class {ClassName + "_jint"} " + "{");
            sb.AppendLine();
            sb.AppendLine("        InitViewWidgets() {");
            sb.AppendLine();
            sb.AppendLine($"            let v = Iuker.ViewModule.GetJintView('{ClassName}');");
            sb.AppendLine();
            AppendWidgetCodeStr(sb, _containerList, "GetJintContainer", "获取容器控件");
            AppendWidgetCodeStr(sb, _buttonList, "GetJintButton", "获取按钮控件");
            AppendWidgetCodeStr(sb, _textList, "GetJintText", "获取文本控件");
            AppendWidgetCodeStr(sb, _inputFieldList, "GetJintInputField", "获取输入框控件");
            AppendWidgetCodeStr(sb, _imageList, "GetJintImage", "获取图片控件");
            AppendWidgetCodeStr(sb, _rawImageList, "GetJintRawImage", "获取原始图片控件");
            AppendWidgetCodeStr(sb, _toggleList, "GetJintToggle", "获取开关控件");
            AppendWidgetCodeStr(sb, _sliderList, "GetJintSlider", "获取滑动器控件");

            sb.AppendLine();
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            FileUtility.WriteAllText(targetScriptPath, sb.ToString());
            TsProj.AddLine("Mvda" + "\\" + "ContainerAndConstant" + "\\" + ClassName + "_jint", son).UpdateToFile(son.TsProjPath);
        }

        private void CreateJintConstant(SonProject son, string targetScriptPath)
        {
            var sb = new StringBuilder().AppendTypeScriptFileNode(EditorConstant.HostClientName,
                EditorConstant.HostClientEmail, "视图常量Typescript脚本（使用Jint执行引擎）。");

            WriteNameSpaceHeader(sb);
            sb.AppendLine();
            sb.AppendLine($"    export class {ClassName}_constant_jint " + "{");
            sb.AppendLine();
            _containerList.ForEach(e => WriteFieldConstant(sb, e));
            _buttonList.ForEach(e => WriteFieldConstant(sb, e));
            _textList.ForEach(e => WriteFieldConstant(sb, e));
            _inputFieldList.ForEach(e => WriteFieldConstant(sb, e));
            _imageList.ForEach(e => WriteFieldConstant(sb, e));
            _rawImageList.ForEach(e => WriteFieldConstant(sb, e));
            _toggleList.ForEach(e => WriteFieldConstant(sb, e));
            _sliderList.ForEach(e => WriteFieldConstant(sb, e));
            sb.AppendLine();
            sb.AppendLine("    }");
            sb.AppendLine("}");

            FileUtility.WriteAllText(targetScriptPath, sb.ToString());
            TsProj.AddLine("Mvda" + "\\" + "ContainerAndConstant" + "\\" + ClassName + "_constant_jint", son).UpdateToFile(son.TsProjPath);
        }

        private static void WriteFieldConstant(StringBuilder sb, string name)
        {
            var targetGo = viewWidgetsDictionary[name];
            var path = GetWidgetPath(targetGo, targetGo.Parent(), "");
            sb.AppendLine($"        public static {name}: string = {path};");
        }

        private static void AppendWidgetCodeStr(StringBuilder sb, List<string> elementList, string methodName,
            string node)
        {
            sb.AppendLine($"            //   {node}");
            elementList.ForEach(e =>
            {
                var targetGo = viewWidgetsDictionary[e];
                var getPath = GetWidgetPath(targetGo, targetGo.Parent(), "");
                sb.AppendLine($"            v.{methodName}({getPath});");
            });
            sb.AppendLine();
        }

    }
}