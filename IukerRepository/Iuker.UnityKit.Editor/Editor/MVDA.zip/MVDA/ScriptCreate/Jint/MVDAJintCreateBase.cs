﻿using System.Text;

namespace Iuker.UnityKit.Editor.MVDA.ScriptCreate.Jint
{
    public class MVDAJintCreateBase : MVDACreaterBase
    {
        protected string ClassName => seletedGo.name;
        protected string CommonTsNameSpaceStr = "Iuker_Project";

        protected void WriteNameSpaceHeader(StringBuilder sb)
        {
            sb.AppendLine($"namespace {CommonTsNameSpaceStr} " + "{");
        }
    }
}