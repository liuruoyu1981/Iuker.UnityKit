﻿using Iuker.Common;
using Iuker.UnityKit.Run.LinqExtensions;
using Iuker.UnityKit.Run.Module.View.MVDA;
using Iuker.UnityKit.Run.Module.View.ViewWidget;
using UnityEditor;
using UnityEngine;

namespace Iuker.UnityKit.Editor.MVDA
{
    /// <summary>
    /// MVDA视图脚本创建器
    /// 按钮交互行为脚本创建
    /// </summary>
    public partial class MVDACreater
    {
        public void MenuButtonClickScript()
        {
            if (sIsError) return;
            if (Selection.gameObjects.Length == 1 && Selection.gameObjects[0].name.Contains("view"))
            {
                seletedGo = Selection.gameObjects[0];
                SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
            }
            else if (Selection.gameObjects.Length == 1)
            {
                ViewWidgetsExtensions.FindViewRoot(Selection.gameObjects[0].Parent(), out seletedGo);
                _buttonList.Add(Selection.gameObjects[0].name);
            }
            else
            {
                EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件，请重新选择！", "确定");
                return;
            }

            CreateButtonClickScripts();
            viewWidgetsDictionary.Clear();
            _buttonList.Clear();
            AssetDatabase.Refresh();
        }

        public void CreateButtonScript(string actionType)
        {
            GameObject cell = null;
            if (sIsError) return;
            if (Selection.gameObjects.Length == 1 && Selection.gameObjects[0].name.Contains("view"))
            {
                seletedGo = Selection.gameObjects[0];
                SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
            }
            else if (Selection.gameObjects.Length == 1)
            {
                var goName = seletedGo.name;
                var isCell = goName.EndsWith("cell") ||
                             goName.Substring(0, goName.Length - 3).EndsWith("cell");

                if (isCell == false)
                {
                    EditorUtility.DisplayDialog("目标错误", "模板控件必须以cell结束命名或类似cell_1这样的索引标号结尾，请确定选择了正确的模板控件！", "确定");
                    return;
                }
                cell = seletedGo;
                ViewWidgetsExtensions.FindViewRoot(Selection.gameObjects[0].Parent(), out seletedGo);
            }
            else
            {
                EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件，请重新选择！", "确定");
                return;
            }

            if (cell != null)
            {
                var cellClassName = GetCellName(cell.name);
                CreateActionResponserScript(cellClassName, actionType, seletedGo.name, "IButton", ViewScriptType.Widget, true);
            }
            AssetDatabase.Refresh();
        }

        public static void MenuButtonPointEnterScript()
        {
            GameObject cell = null;
            if (sIsError) return;
            if (Selection.gameObjects.Length == 1 && Selection.gameObjects[0].name.Contains("view"))
            {
                seletedGo = Selection.gameObjects[0];
                SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
            }
            else if (Selection.gameObjects.Length == 1)
            {
                var goName = seletedGo.name;
                var isCell = goName.EndsWith("cell") ||
                    goName.Substring(0, goName.Length - 3).EndsWith("cell");

                if (isCell == false)
                {
                    EditorUtility.DisplayDialog("目标错误", "模板控件必须以cell结束命名或类似cell_1这样的索引标号结尾，请确定选择了正确的模板控件！", "确定");
                    return;
                }
                cell = seletedGo;
                ViewWidgetsExtensions.FindViewRoot(Selection.gameObjects[0].Parent(), out seletedGo);
            }
            else
            {
                EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件，请重新选择！", "确定");
                return;
            }

            if (cell != null)
            {
                var cellClassName = GetCellName(cell.name);
                CreateActionResponserScript(cellClassName, "OnPointerEnter", seletedGo.name, "IButton", ViewScriptType.Widget, true);
            }
            AssetDatabase.Refresh();
        }


        private static void CreateButtonClickScripts()
        {
            foreach (var buttonName in _buttonList)
            {
                var endStr = buttonName.Substring(0, buttonName.LastIndexOf('_'));
                if (buttonName.EndsWith("cell") || endStr.EndsWith("cell"))
                {
                    var cellClassName = GetCellName(buttonName);
                    CreateActionResponserScript(cellClassName, "OnClick", seletedGo.name, "IButton", ViewScriptType.Widget, true);
                }
                else
                {
                    CreateActionResponserScript(buttonName, "OnClick", "Button" + "/" + buttonName, "IButton");
                }
            }
        }

        private static string GetCellName(string goName)
        {
            var cellClassName = goName.EndsWith("cell")
                ? goName
                : goName.TrimTargetCharAfter("_");
            return cellClassName;
        }



    }
}