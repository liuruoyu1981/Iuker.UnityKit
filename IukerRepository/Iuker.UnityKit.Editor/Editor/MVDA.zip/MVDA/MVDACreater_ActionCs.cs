﻿using Iuker.UnityKit.Run.LinqExtensions;
using Iuker.UnityKit.Run.Module.View.ViewWidget;
using UnityEditor;

namespace Iuker.UnityKit.Editor.MVDA
{
    /// <summary>
    /// MVDA视图脚本创建器
    /// 视图交互行为脚本创建
    /// </summary>
    public partial class MVDACreater
    {
        public static void MenuInputFiledScript()
        {
            if (sIsError) return;
            if (Selection.gameObjects.Length == 1 && Selection.gameObjects[0].name.Contains("view"))
            {
                seletedGo = Selection.gameObjects[0];
                SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
            }
            else if (Selection.gameObjects.Length == 1)
            {
                ViewWidgetsExtensions.FindViewRoot(Selection.gameObjects[0].Parent(), out seletedGo);
                _inputFieldList.Add(Selection.gameObjects[0].name);
            }
            else
            {
                EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件，请重新选择！", "确定");
                return;
            }
            CreateInputFieldScripts();
            viewWidgetsDictionary.Clear();
            _inputFieldList.Clear();
            AssetDatabase.Refresh();
        }

        public static void MenuToggleScript()
        {
            if (sIsError) return;
            if (Selection.gameObjects.Length == 1 && Selection.gameObjects[0].name.Contains("view"))
            {
                seletedGo = Selection.gameObjects[0];
                SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
            }
            else if (Selection.gameObjects.Length == 1)
            {
                ViewWidgetsExtensions.FindViewRoot(Selection.gameObjects[0].Parent(), out seletedGo);
                _toggleList.Add(Selection.gameObjects[0].name);
            }
            else
            {
                EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件，请重新选择！", "确定");
                return;
            }
            CreateToggleScripts();
            viewWidgetsDictionary.Clear();
            _toggleList.Clear();
            AssetDatabase.Refresh();
        }

        public static void MenuSliderScript()
        {
            if (sIsError) return;
            switch (Selection.gameObjects.Length)
            {
                case 1 when Selection.gameObjects[0].name.Contains("view"):
                    seletedGo = Selection.gameObjects[0];
                    SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
                    break;
                case 1:
                    Selection.gameObjects[0].Parent().FindViewRoot(out seletedGo);
                    _sliderList.Add(Selection.gameObjects[0].name);
                    break;
                default:
                    EditorUtility.DisplayDialog("目标错误", "不能一次选中多个目标控件，请重新选择！", "确定");
                    return;
            }
            CreateSliderScripts();
            viewWidgetsDictionary.Clear();
            _sliderList.Clear();
            AssetDatabase.Refresh();
        }

    }
}