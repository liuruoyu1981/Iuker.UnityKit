﻿using System;
using System.Collections.Generic;
using System.Linq;
using Iuker.Common;
using Iuker.UnityKit.Run.Base.Config;
using Iuker.UnityKit.Run.Base.Config.Develop;
using Iuker.UnityKit.Run.LinqExtensions;
using Iuker.UnityKit.Run.Module.View.ViewWidget;
using UnityEditor;
using UnityEngine;

namespace Iuker.UnityKit.Editor.MVDA
{
    public class MVDACreaterBase
    {
        protected static GameObject seletedGo;
        protected static GameObject _viewRoot;
        protected static bool sIsError;
        private static readonly Dictionary<string, Type> UnityDefualtNameDictionary = new Dictionary<string, Type>
        {
            {"Text",typeof( UnityEngine.UI.Text) },
            {"Button",typeof( UnityEngine.UI.Button) },
            {"InputField",typeof(UnityEngine.UI.InputField) },
            {"Toggles",typeof(UnityEngine.UI.Toggle) },
            {"Image",typeof(UnityEngine.UI.Image) },
            {"RawImage",typeof(UnityEngine.UI.RawImage) },
            {"Slider",typeof(UnityEngine.UI.Slider) },
            {"Dropdown",typeof(UnityEngine.UI.Dropdown) },
        };

        /// <summary>
        /// 视图根集合
        /// </summary>
        private static readonly HashSet<string> ViewRootHashSet = new HashSet<string>
        {
            "view_background_root",
            "view_normal_root",
            "view_parasitic_root",
            "view_popup_root",
            "view_top_root",
            "view_mask_root",
        };

        protected static List<string> _containerList;
        protected static List<string> _buttonList;
        protected static List<string> _textList;
        protected static List<string> _inputFieldList;
        protected static List<string> _imageList;
        protected static List<string> _rawImageList;
        protected static List<string> _toggleList;
        protected static List<string> _sliderList;
        protected static List<string> _tabgroupList;
        protected static List<string> _listViewList;

        protected static Dictionary<string, GameObject> viewWidgetsDictionary { get; set; }
            = new Dictionary<string, GameObject>();
        protected readonly SonProject mSelectSon;

        protected MVDACreaterBase()
        {
            viewWidgetsDictionary.Clear();
            seletedGo = Selection.activeGameObject;
            seletedGo.FindViewRoot(out _viewRoot);
            var mTempSonName = _viewRoot.name.Split('_').ToList().SelectUnion("_", 1, 2);
            mTempSonName = mTempSonName.Substring(1, mTempSonName.Length - 1);
            mSelectSon = RootConfig.Instance.AllProjectsSons.Find(s => s.CompexName.ToLower() == mTempSonName) ?? RootConfig.GetCurrentSonProject();

            switch (seletedGo.name)
            {
                case "view_background_root":
                case "view_normal_root":
                case "view_parasitic_root":
                case "view_popup_root":
                case "view_top_root":
                case "view_mask_root":
                    sIsError = true;
                    EditorUtility.DisplayDialog("错误", "不能选择视图分层挂载根对象", "确定");
                    break;
            }

            SaveAllViewWidgets(seletedGo, viewWidgetsDictionary);
        }

        protected static void SaveAllViewWidgets(GameObject root, Dictionary<string, GameObject> elementDictionary)
        {
            var trm = root.transform;
            var i = 0;
            var childCount = trm.childCount;
            while (i < childCount)
            {
                var currentGo = trm.GetChild(i).gameObject;
                if (!elementDictionary.ContainsKey(currentGo.name)
                    && !UnityDefualtNameDictionary.ContainsKey(currentGo.name) // 不是unity3d UI组件的默认名
                )   // 不是容器
                {
                    elementDictionary.Add(currentGo.name, currentGo.gameObject);
                }
                SaveAllViewWidgets(currentGo.gameObject, elementDictionary);
                i++;
            }
            var keys = viewWidgetsDictionary.Keys.ToList();
            // 分别保存所有类型控件名至对应列表
            _containerList = keys.FindAll(r => r.StartsWith("container"));
            _buttonList = keys.FindAll(r => r.StartsWith("button") && r != "button_root");
            _textList = keys.FindAll(r => r.StartsWith("text"));
            _inputFieldList = keys.FindAll(r => r.StartsWith("inputfield"));
            _imageList = keys.FindAll(r => r.StartsWith("image"));
            _rawImageList = keys.FindAll(r => r.StartsWith("rawimage"));
            _toggleList = keys.FindAll(r => r.StartsWith("toggle"));
            _sliderList = keys.FindAll(r => r.StartsWith("slider"));
            _tabgroupList = keys.FindAll(r => r.StartsWith("tabgroup"));
            _listViewList = keys.FindAll(r => r.StartsWith("listview"));
        }

        protected static string GetWidgetPath(GameObject source, GameObject parent, string path)
        {
            while (true)
            {
                var parentName = parent.name;
                var grandfatherName = parent.Parent().name;
                if (!parentName.StartsWith("view"))
                {
                    path = parentName + "/" + path;
                    parent = parent.Parent();
                    continue;
                }
                if (!ViewRootHashSet.Contains(grandfatherName))
                {
                    path = parentName + "/" + path;
                    parent = parent.Parent();
                    continue;
                }
                var result = "\"" + path + source.name + "\"";
                return result;
            }
        }

    }
}